export class Product {
    public id: any = 0;
    public name: string = '';
    public description: string = '';
    public price: number = 0;
    public category: string = '';
    public imageUrl: string = '';
    public stockQty: number = 0;
}
