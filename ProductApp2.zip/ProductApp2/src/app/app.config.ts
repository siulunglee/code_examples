import { ApplicationConfig, importProvidersFrom, provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from '@angular/core';
import { provideRouter, withComponentInputBinding } from '@angular/router';

import { routes } from './app.routes';
import { provideHttpClient } from '@angular/common/http';

import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { ProductInMemDbService } from './services/product-in-mem-db.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(),
    // Import the in-memory web API module to simulate a backend
    // This allows us to use the ProductInMemDbService to provide product data in standalone mode
    // importProidersFrom is needed to import the in-memory web API module
    importProvidersFrom(HttpClientInMemoryWebApiModule.forRoot(
      ProductInMemDbService, {
        dataEncapsulation: false, // Disable data encapsulation to allow direct access to the data      
        passThruUnknownUrl: true, // Allow passing through unknown URLs to the real backend
        delay: 500 // Simulate a delay for API responses
      }
    )),
      //provideRouter(routes, withComponentInputBinding()),
    //ProductInMemDbService // Provide the in-memory database service
    importProvidersFrom(ReactiveFormsModule), // Import ReactiveFormsModule for form handling
    importProvidersFrom(FormsModule), // Import ReactiveFormsModule for form handling
    importProvidersFrom(ProductInMemDbService), // Import the ProductInMemDbService to provide product data
  ]
};
