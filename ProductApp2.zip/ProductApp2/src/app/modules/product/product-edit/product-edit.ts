import { Component, OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Form, FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ProductService } from '../../../services/product.service';
import { ProductInMemDbService } from '../../../services/product-in-mem-db.service';
import { Product } from '../../../data/product/product.model';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-product-edit',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './product-edit.html',
  styleUrl: './product-edit.scss'
})

export class ProductEdit implements OnInit {

  _product: Product = new Product(); // Initialize _product to null 

  editProductForm: FormGroup;

  // editProductForm: FormGroup = new FormGroup({
  //   id: new FormControl(1, [Validators.required]),
  //   name: new FormControl('test product'),
  //   description: new FormControl('Test product description'),
  //   price: new FormControl(50, [Validators.required, Validators.min(1)]),
  //   category: new FormControl('general'),
  //   imageUrl: new FormControl('/1.png'),
  //   stockQty: new FormControl(10, [Validators.required, Validators.min(0)])
  // });

  constructor(private productService: ProductService, private builder: FormBuilder,
    private aRoute: ActivatedRoute, private router: Router, private productInMemDbService: ProductInMemDbService) {
    // Initialization logic can go here
    // You can also inject other services if needed
    this.productService = productService;
    this.editProductForm = builder.group({
      id: "",
      name: new FormControl('test product'),
      description: new FormControl('Test product description'),
      price: new FormControl(50, [Validators.required, Validators.min(1)]),
      category: new FormControl('general'),
      imageUrl: new FormControl('/1.png'),
      stockQty: new FormControl(10, [Validators.required, Validators.min(0)])
    })
  }

  ngOnInit() {
    let productIdString: string = this.aRoute.snapshot.paramMap.get('id') || '';
    let productIdNumber: number = 0;
    // Check if productId is a valid number
    if (productIdString) {
      productIdNumber = parseInt(productIdString, 10);
      //this.editProductForm.value.id = productIdNumber; // Set the product ID in the form
    } else {
      console.error('Product ID not found in route parameters');
      return;
    }

    //this._product = this.router.getCurrentNavigation()?.extras.state?.['product'] || null;

    this.productService.getProductById(productIdNumber).subscribe({
      next: (data: any) => {
        this._product = data || null;
      },
      error: (error: any) => {
        console.error('Error fetching products:', error);
      },
      complete: () => {
        this.editProductForm.patchValue(this._product || {}); // Patch the form with the product data if available
      }
    });


  }


  onSubmit() {
    if (this.editProductForm.valid) {
      const productData = this.editProductForm.value;
      console.log('Form submitted with data:', productData);

      //productData.id = this.product.id; // Ensure the product ID is set correctly
      // Call the service to add the product
      this.productService.updateProduct(productData).subscribe({
        next: (response: any) => {
          console.log('Product updated successfully:', response);
          // Optionally reset the form or navigate to another page
          this.router.navigateByUrl('/products-list'); // Navigate to the product list or another page after successful addition
        },
        error: (error: string) => {
          console.error('Error adding product:', error);
        }
      });
    } else {
      console.error('Form is invalid');
    }
  }
  resetForm() {
    throw new Error('Method not implemented.');
  }

}
