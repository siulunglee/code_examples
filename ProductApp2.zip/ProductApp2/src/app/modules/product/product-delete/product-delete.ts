import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../../services/product.service';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-delete',
  imports: [],
  templateUrl: './product-delete.html',
  styleUrl: './product-delete.scss'
})
export class ProductDelete implements OnInit {

  constructor(private productService: ProductService, private location: Location, private route: ActivatedRoute) {
    // Initialization logic can go here
    // You can also inject other services if needed
    this.productService = productService;
    this.location = location;
  }

  ngOnInit() {
    // This method is called after the component is initialized
    // You can perform any additional setup here, such as fetching initial data
    console.log('ProductDelete component initialized');
    let productIdString: string = this.route.snapshot.paramMap.get('id') || '';
    let productIdNumber: number = 0;

    // Check if productId is a valid number
    if (productIdString) {
      productIdNumber = parseInt(productIdString, 10);
      //this.editProductForm.value.id = productIdNumber; // Set the product ID in the form
    } else {
      console.error('Product ID not found in route parameters');
      return;
    }

    this.productService.deleteProduct(productIdNumber).subscribe({
      next: (response: any) => {
        console.log('Product deleted successfully:', response);
        // Optionally reset the form or navigate to another page
        this.location.back(); // Navigate back to the previous page
      },
      error: (error: string) => {
        console.error('Error deleting product:', error);
      }
    }
    );
  }
}