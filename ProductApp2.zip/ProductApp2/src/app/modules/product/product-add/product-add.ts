import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ProductService } from '../../../services/product.service';
import { Location } from '@angular/common';
import { Router } from '@angular/router';


@Component({
  selector: 'app-product-add',
  imports: [ReactiveFormsModule],
  templateUrl: './product-add.html',
  styleUrl: './product-add.scss'
})
export class ProductAdd implements OnInit {

  addProductForm: FormGroup = new FormGroup({
    id: new FormControl(1, [Validators.required]),
    createdAt: new FormControl(new Date(Date.now())),
    updatedAt: new FormControl(new Date(Date.now())),
    name: new FormControl('test product', [Validators.required, Validators.minLength(3)]),
    description: new FormControl('test product description', [Validators.required, Validators.minLength(10)]),
    price: new FormControl(50, [Validators.required, Validators.min(1)]),
    category: new FormControl('general', [Validators.required]),
    imageUrl: new FormControl(''),
    stockQty: new FormControl(10, [Validators.required, Validators.min(0)])
  });



  constructor(private productService: ProductService, private fb: FormBuilder,
    private route: Router, private location: Location) {
    // Initialization logic can go here
    // You can also inject other services if needed
    this.productService = productService;
  }

  ngOnInit() {
    // This method is called after the component is initialized
    // You can perform any additional setup here, such as fetching initial data
    // For example, you might want to fetch existing products or categories
    console.log('ProductAdd component initialized');
    // this.productService.getProducts().subscribe(products => {
    //   console.log('Fetched products:', products);
    // });
  }


  onSubmit() {
    if (this.addProductForm.valid) {
      const productData = this.addProductForm.value;
      console.log('Form submitted with data:', productData);
      // Call the service to add the product
      this.productService.addProduct(productData).subscribe({
        next: (response: any) => {
          console.log('Product added successfully:', response);
          // Optionally reset the form or navigate to another page
          this.location.back; // Navigate back to the previous page
        },
        error: (error: string) => {
          console.error('Error adding product:', error);
        }
      });
    } else {
      console.error('Form is invalid');
    }
  }

  addSampleProduct() {
    // Logic to add a sample product
    
  };

  resetForm() {
    throw new Error('Method not implemented.');
  }

}
