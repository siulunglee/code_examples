import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../../services/product.service'; 
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-sample-products',
  imports: [],
  templateUrl: './add-sample-products.html',
  styleUrl: './add-sample-products.scss'
})
export class AddSampleProducts implements OnInit {

  constructor(private productService: ProductService,
              private route: Router
  ) {
    // Initialization logic can go here
    // You can also inject other services if needed
  }

  ngOnInit() {    
    console.log('AddSampleProducts component initialized ...');
    this.addSampleProducts() // Call the method to add sample products when the component initializes
  }

  addSampleProducts() {
    console.log('Adding sample products...');
    // Logic to add sample products goes here

    this.productService.addSampleProducts().subscribe({
      next: (response: any) => {
        console.log('Sample products added successfully:', response);
        // Optionally reset the form or navigate to another page

        this.route.navigate(['/products-list']); // Navigate to the product listing page
      },
      error: (error: string) => {
        console.error('Error adding sample products:', error);
      }
    });
  } 
}
