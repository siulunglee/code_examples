import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSampleProducts } from './add-sample-products';

describe('AddSampleProducts', () => {
  let component: AddSampleProducts;
  let fixture: ComponentFixture<AddSampleProducts>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddSampleProducts]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddSampleProducts);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
