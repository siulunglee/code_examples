import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Product } from '../../../data/product/product.model';
import { ProductService } from '../../../services/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-listing',
  imports: [CommonModule],
  templateUrl: './product-listing.html',
  styleUrls: ['./product-listing.scss']
})
export class ProductListing implements OnInit {

  router: Router;
  products: any[] = [];
  // products: any[] = [
  //   { id: 1, name: 'Product 1', description: 'Description 1', price: 100, category: 'Category 1', imageUrl: '/1.png', stockQty: 10, createdAt: new Date(), updatedAt: new Date() },
  //   { id: 2, name: 'Product 2', description: 'Description 2', price: 200, category: 'Category 2', imageUrl: '/2.png', stockQty: 20, createdAt: new Date(), updatedAt: new Date() },
  //   { id: 3, name: 'Product 3', description: 'Description 3', price: 300, category: 'Category 3', imageUrl: '/3.png', stockQty: 30, createdAt: new Date(), updatedAt: new Date() },
  //   // Add more products as needed
  // ];
  constructor(private productService: ProductService, router: Router) {
    // Initialization logic can go here
    this.router = router;
  }

  ngOnInit() {
    this.productService.getProducts().subscribe({
      next: (data: any) => {
        this.products = data || [];
      },
      error: (error: any) => {
        console.error('Error fetching products:', error);
      }
    });
  } 

  addToCart(product: Product) {
    console.log('Product added to cart:', product);
  }

  editProduct(product: Product) {
    console.log('Edit product:', product);
    // Navigate to the edit page or open a modal for editing
    
    this.router.navigate(['/product-edit', product.id]);
  }

  deleteProduct(product: any) {
    console.log('Delete product with ID:', product);
    // Call the service to delete the product
    this.productService.deleteProduct(product).subscribe({
      next: (response: any) => {
        console.log('Product deleted successfully:', response);
        // Optionally refresh the product list or navigate to another page
        this.ngOnInit(); // Refresh the product list
      },
      error: (error: string) => {
        console.error('Error deleting product:', error);
      }
    });
  }

  viewProductDetails(productId: number) {
    console.log('View details for product ID:', productId);
    throw new Error('Method not implemented.');
  }

}
