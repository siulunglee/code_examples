import { Injectable } from '@angular/core';
import { map, catchError, tap } from 'rxjs/operators'; 
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse,
  HttpParams,
} from '@angular/common/http';
import { Product } from '../data/product/product.model';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class ProductDotNetService {

  //dataStorageLocationUrl: string = 'http://localhost:4200';
  //api = `${this.dataStorageLocationUrl}/data/products.json`;
  //api = 'api/products'; // Use the in-memory API endpoint
  api = 'http://localhost:7285/api'; // Use the actual API endpoint if not using in-memory
  headers = new HttpHeaders().set('Content-Type', 'application/json');

  constructor(private http: HttpClient) { }

  getProducts() {
    // return [
    //   { id: 1, name: 'Product 1', description: 'Description 1', price: 100, category: 'Category 1', imageUrl: '/1.png', stockQty: 10, createdAt: new Date(), updatedAt: new Date() },
    //   { id: 2, name: 'Product 2', description: 'Description 2', price: 200, category: 'Category 2', imageUrl: '/2.png', stockQty: 20, createdAt: new Date(), updatedAt: new Date() },
    //   { id: 3, name: 'Product 3', description: 'Description 3', price: 300, category: 'Category 3', imageUrl: '/3.png', stockQty: 30, createdAt: new Date(), updatedAt: new Date() },
    // ];
    return this.http.get<Product[]>(`${this.api}`, {headers: this.headers}).pipe(
      map((data) => {
        const res:any = data;
        if(res) {
          return res || [];
        }
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('Error fetching products:', error);   
        throw error;
      })
    ); 
    //return [];
  }
  
  getProductById(id: number) {

    let _product: any = null;

    let api = `${this.api}/${id}'`; // Use the in-memory API endpoint

    return this.http.get<Product>(api, {headers: this.headers}).pipe(
      map((data) => {
        const res:any = data;
        if(res) {
          return res;
        }
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('Error fetching products:', error);   
        throw error;
      })
    ); 
    


    // console.log(_product)
    // return _product;
  }

  addProduct(product: any): any {
    // Logic to add a product
    // This could involve sending a POST request to the server
    console.log('Product added:', product);
    return this.http.post<any>(this.api, product, { headers: this.headers }).pipe(
      map((response: any) => {
        response = 'Product added successfully';
        console.log('Product added successfully:', response);
        return response;
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('Error adding product:', error);
        throw error;
      })
    );
  }

  updateProduct(product: any): Observable<any> {
    // Logic to update a product
    // This could involve sending a PUT request to the server

    return this.http.put(this.api, product, { headers: this.headers });
    
  }

  
  deleteProduct(id: number): any {
    // Logic to delete a product
    // This could involve sending a DELETE request to the server
    return this.http.delete(`${this.api}/${id}`, { headers: this.headers }).pipe(
      map((response: any) => {
        console.log('Product deleted successfully:', response);
        return response;
      }),
      catchError((error: HttpErrorResponse) => {
        console.error('Error deleting product:', error);
        throw error;
      })
    );
  }    

}
