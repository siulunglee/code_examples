import { Injectable } from '@angular/core';
import { map, catchError } from 'rxjs/operators'; 
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse,
  HttpParams,
} from '@angular/common/http';
import { Product } from '../data/product/product.model';
import { InMemoryDbService } from 'angular-in-memory-web-api';

@Injectable({
  providedIn: 'root'
})

export class ProductInMemDbService implements InMemoryDbService{
  // This service simulates a product database in memory.
  // It is used to provide product data without needing a real backend.

  dataStorageLocationUrl: string = 'http://localhost:4200';
  api = `${this.dataStorageLocationUrl}/data/products.json`;
  headers = new HttpHeaders().set('Content-Type', 'application/json');

  //constructor(private http: HttpClient) { }

  createDb() {  

    // This method simulates a database of products from JSON data file.

    let products = 
    [
      { id: 1, name: 'Product 1', description: 'Description 1', price: 100, category: 'Category 1', imageUrl: '/1.png', stockQty: 10},
      { id: 2, name: 'Product 2', description: 'Description 2', price: 200, category: 'Category 2', imageUrl: '/2.png', stockQty: 20},
      { id: 3, name: 'Product 3', description: 'Description 3', price: 300, category: 'Category 3', imageUrl: '/3.png', stockQty: 30},
      // Add more products as needed
    ];

    //let products: Product[] = [];

    // this.http.get(this.api, {headers: this.headers}).pipe(
    //   map((data) => {
    //     const res:any = data;
    //     if(res) {
    //       // instead of returning res.result, we assign it to a variable
    //       //return res.result || [];
    //       products = res.result || [];
    //     }
    //   }),
    //   catchError((error: HttpErrorResponse) => {
    //     console.error('Error fetching products:', error);   
    //     throw error;
    //   })
    //); 
    
    return { products };
  }

    genId(products: Product[]): number {
    return products.length > 0 ? Math.max(...products.map(product => product.id)) + 1 : 11;
  }
}
