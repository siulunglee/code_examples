import { Routes } from '@angular/router';

export const routes: Routes = [
    { path: 'products-list', 
        loadComponent: () => import('./modules/product/product-listing/product-listing').then(m => m.ProductListing) 
    },
    {
        path: 'products/:id',
        loadComponent: () => import('./modules/product/product-detail/product-detail').then(m => m.ProductDetail)   
    },
    {
        path: 'product-add',
        loadComponent: () => import('./modules/product/product-add/product-add').then(m => m.ProductAdd)
    },
    {
        path: 'product-edit/:id',
        loadComponent: () => import('./modules/product/product-edit/product-edit').then(m => m.ProductEdit)
    },
    {
        path: 'product-delete/:id',
        loadComponent: () => import('./modules/product/product-delete/product-delete').then(m => m.ProductDelete)
    },
    {
        path: 'add-sample-products',
        loadComponent: () => import('./modules/product/add-sample-products/add-sample-products').then(m => m.AddSampleProducts)  
    },
    {
        path: 'products/search/:query',
        loadComponent: () => import('./modules/product/product-search/product-search').then(m => m.ProductSearch)
    },
    { path: '', 
        loadComponent: () => import('./modules/home/home').then(m => m.Home) 
    },

    { path: '**', 
        loadComponent: () => import('./modules/not-found/not-found').then(m => m.NotFound) 
    },
];
