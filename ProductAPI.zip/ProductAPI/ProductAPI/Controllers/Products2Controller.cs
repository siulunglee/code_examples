﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ProductAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Products2Controller : ControllerBase
    {
        // This controller is intentionally left empty for demonstration purposes.
        // You can add actions here similar to ProductsController or leave it as a placeholder.

        // Example action:
        //[HttpGet]
        //public IActionResult Get()
        //{
        //    return Ok("This is the Products2 controller.");
        //}
        //// Additional actions can be added as needed.
    }
}
